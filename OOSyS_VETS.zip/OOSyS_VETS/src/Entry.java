
public class Entry {
	public static void main(String[] args) {
		// Sys sys = new Sys();
		// sys.entryMenu();

		new Sys().entryMenu();
	}
}
