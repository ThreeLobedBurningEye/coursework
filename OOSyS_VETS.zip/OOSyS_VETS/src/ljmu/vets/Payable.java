package ljmu.vets;

public interface Payable {
	public Double getSurgeryCost();
	public Double getPublicCost() throws Exception;
}
