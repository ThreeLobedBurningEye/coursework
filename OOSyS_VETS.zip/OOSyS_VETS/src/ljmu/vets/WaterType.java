package ljmu.vets;

public enum WaterType {
	SALT, FRESH;
}
